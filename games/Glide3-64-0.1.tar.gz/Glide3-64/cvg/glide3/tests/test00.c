/*
** Insert new header here
**
**
** $Revision: 1.1.1.1 $ 
** $Date: 2000/03/29 04:20:02 $ 
**
*/

#include <stdlib.h>
#include <stdio.h>
#ifndef __linux__
#include <conio.h>
#else
#include <linutil.h>
#endif
#include <assert.h>
#include <string.h>

#include <glide.h>
#include "tlib.h"

#define NIKI 1

int hwconfig;
static const char *version;

static const char name[]    = "test00";
static const char purpose[] = "Clear screen to blue";
static const char usage[]   = "-n <frames> -r <res> -d <filename>";

int 
main( int argc, char **argv) 
{
  char match; 
  char **remArgs;
  int  rv;
  
  GrScreenResolution_t resolution = GR_RESOLUTION_640x480;
  float                scrWidth   = 640.0f;
  float                scrHeight  = 480.0f;
  int frames                      = -1;
  FxBool               scrgrab = FXFALSE;
  char                 filename[256];
  FxU32                wrange[2];
  
#if NIKI
  printf("\nmain:\n");
#endif

  /* Initialize Glide */
  grGlideInit();
#if 0
  printf("\n _GlideRoot.GCs[0].base_ptr: %x\n", _GlideRoot.GCs[0].base_ptr);
#endif
  assert( hwconfig = tlVoodooType() );
#if NIKI
  printf("\n tlVodooType: %d (%s)\n", hwconfig, grGetString(GR_HARDWARE));
#endif

  /* Process Command Line Arguments */
  while( rv = tlGetOpt( argc, argv, "nrd", &match, &remArgs ) ) {
    if ( rv == -1 ) {
      printf( "Unrecognized command line argument\n" );
      printf( "%s %s\n", name, usage );
      printf( "Available resolutions:\n%s\n",
             tlGetResolutionList() );
      return(1);
    }
    switch( match ) {
    case 'n':
      frames = atoi( remArgs[0] );
      break;
    case 'r':
      resolution = tlGetResolutionConstant( remArgs[0], 
                                           &scrWidth, 
                                           &scrHeight );
      break;
    case 'd':
      scrgrab = FXTRUE;
      frames = 1;
      strcpy(filename, remArgs[0]);
      break;
    }
  }
  
  tlSetScreen( scrWidth, scrHeight );
  
  version = grGetString( GR_VERSION );
#if NIKI
  printf("\n version: '%s'\n", version);
#endif
  
  printf( "%s:\n%s\n", name, purpose );
  printf( "%s\n", version );
  printf( "Resolution: %s\n", tlGetResolutionString( resolution ) );
  if ( frames == -1 ) {
    printf( "Press A Key To Begin Test.\n" );
    tlGetCH();
  }
  
  grSstSelect( 0 );
  assert( grSstWinOpen(tlGethWnd(),
                       resolution,
                       GR_REFRESH_60Hz,
                       GR_COLORFORMAT_ABGR,
                       GR_ORIGIN_UPPER_LEFT,
                       2, 1 ) );
  
  grGet(GR_WDEPTH_MIN_MAX, 8, wrange);  
#if NIKI
  printf("\n\r wrange: %d, %d\n\r", wrange[0], wrange[1]);
#endif

  tlConSet( 0.0f, 0.0f, 1.0f, 1.0f,
           60, 30, 0xffffff );
  
#if NIKI
  printf("\n\r tlConSet done\n\r");
  printf("\n\r   H A P P Y ! ! !\n\r");
#endif
  tlConOutput( "Press a key to quit\n" );
  
  while( frames-- && tlOkToRender()) {
    grBufferClear( 0xff0000, 0, wrange[1] );
    tlConRender();
    grBufferSwap( 1 );

    if (hwconfig == TL_VOODOORUSH) {
      tlGetDimsByConst(resolution,
                       &scrWidth, 
                       &scrHeight );
        
      grClipWindow(0, 0, (FxU32) scrWidth, (FxU32) scrHeight);
    } 
    /* grab the frame buffer */
    if (scrgrab) {
      if (!tlScreenDump(filename, (FxU16)scrWidth, (FxU16)scrHeight))
        printf( "Cannot open %s\n", filename);
      scrgrab = FXFALSE;
    }

    if ( tlKbHit() ) frames = 0;
  }
  
  grGlideShutdown();

  return(0);
}

