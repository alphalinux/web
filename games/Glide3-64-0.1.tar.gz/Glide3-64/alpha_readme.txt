Right now, this is the status of the Alpha/Linux driver.

There are some issues.

1) The debugging printf is needed for the driver to work.  (timing
issue.. I'll look into this after the driver doesn't segfault.)

2) Anti-aliasing only draws the outline of the objects.  I'm not sure why.
You can see it with test25 & the 3dfx logo.  In this source, I've hacked
the logo so that some objects are anti-aliased, and some aren't.
See gsplash.c for more info.  It would be really neat to change it into
a spinning Alpha/Linux logo.  (Whatever THAT may be.. ;-) )

3) Some tests segfault.  It appears to be something to do with the stride.
I've double some strides (grep for PGE & stride), but I'm not convinced it
is really the right thing to do.

...

Oh, yeah, before you run any tests, you'll have to add the glide library
to $LD_LIBRARY_PATH.

Right now, this is only glide3.  Glide2 is needed for Mesa. (I
think). But, once we solve the problems here, I think porting glide2
will be a snap.

Niki W. Waibel <niki.waibel@newlogic.at> has done the ground-breaking work
to get things up and running.  He and I are working together to get this
to be fully operational.

-Phil Ezolt- 4/3/2000
ezolt@perf.zko.dec.com
Phillip.Ezolt@compaq.com

BTW.  I think that all of Niki's problems have been solved. 



From ezolt@perf.zko.dec.com Mon Apr  3 20:05:16 2000
Date: Mon, 3 Apr 2000 12:59:23 -0400 (EDT)
From: Phillip Ezolt <ezolt@perf.zko.dec.com>
To: dg@px.uk.com
Subject: Re: source (Glide3.01.32_64 and Device3DFX) (fwd)



--Phil

Compaq:  High Performance Server Division/Benchmark Performance Engineering 
---------------- Alpha, The Fastest Processor on Earth --------------------
Phillip.Ezolt@compaq.com        |C|O|M|P|A|Q|        ezolt@perf.zko.dec.com
------------------- See the results at www.spec.org -----------------------

---------- Forwarded message ----------
Date: Sun, 2 Apr 2000 16:42:46 -0400 (EDT)
From: Phillip Ezolt <ezolt@perf.zko.dec.com>
To: "Niki W. Waibel" <niki.waibel@newlogic.at>
Subject: Re: source (Glide3.01.32_64 and Device3DFX)

Niki,
	Ok.  I've gotten things limping, (not quite running).

I have a spinning 3Dfx in front of me as we speak.. ;-) 
This is on a PWS600.  Do you get a screen blank?  Or does
it just crash? 

If I remove the "writting blah blah" debugging printf, it
doesn't not work.  There is some kind of timing issue. 
(This might be the write-combining stuff they're talking about.)

20 or so of the tests work correctly. 

1) The reason that I was only seeing a blank screen, was because 
The 3dFX logo was causing a segfault.  

Solve this by:
	1) Setting export FX_GLIDE_NO_SPLASH=1
	or
	2) Add

    projected_gvert[i].r = 0.0f;
    projected_gvert[i].g = 0.0f;
    projected_gvert[i].b = 0.0f;
    projected_gvert[i].a = 0.0f;

Right after the GLIDE_PACKED_RGB ifdef in drawShadow. 
I'm not sure what the right solution is.  Alot of the
code seems to NOT be initialized. 

2) AntiAliaising Doesn't seem to work properly.
If you get the rotating 3dfx stuff, it will be in outline mode.
(Strange...) 	

	1)  If you change the calls in 

        grAADrawTriangle(&gvert[0], &gvert[1], &gvert[2],
                       aa_a, aa_b, aa_c);

	to 
	
	grDrawTriangle(&gvert[0], &gvert[1], &gvert[2]);

	It will be ugly, but will work.  I haven't tracked down what
went wrong yet.  I think this is why some of the tests fail. 

	Something is fishy with anti aliasing.  Can you figure it
out? 

3) Some tests segfault. (2 & 3)
	(They are dereferencing a pointer that is off. 
	Instead of 0xff030303, it gets  0xff0303030303040 ) 

	By adding "stride = stride * 2"
	in _grDrawLineStrip/_grAADrawLineStrip, things work.  

	#define GR_VTX_PTR_ARRAY        0x01
	is somehow tied into this.. Maybe it should be doubled.

Enclosed is my test status. 

For some reason gdb won't let me set breakpoints in shared
libraries.. (Annoying)...  So, I've been adding "printf("foo:%f",1/0);
where I want to stop, and have been looking at data there.
 
--Phil

Compaq:  High Performance Server Division/Benchmark Performance Engineering 
---------------- Alpha, The Fastest Processor on Earth --------------------
Phillip.Ezolt@compaq.com        |C|O|M|P|A|Q|        ezolt@perf.zko.dec.com
------------------- See the results at www.spec.org -----------------------

On Sun, 2 Apr 2000, Niki W. Waibel wrote:

> yeah! i got the values too!
> the DAC seems to be init correct.
> then - later - my alphastation255 just halts (halt code 6 or so).
> strange...
> 
> niki
> 
> 

  [Part 2, ""  Text/PLAIN  194 lines]
  [Unable to print this part]

