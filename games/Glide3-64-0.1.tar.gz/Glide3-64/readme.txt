============================================================
>   3Dfx Interactive, Inc.   Glide3 Driver Source Kit      <
============================================================
Voodoo2 Glide 3.X Driver: 3.01

This product may be covered by one or more of the following US
patents, especially when used in conjunction with hardware graphics
accelerators: 5,724,561 5,740,343 5,808,621 5,822,452 5,831,624
5,870,102.


Copyright Notice
================
Copyright (c) 1998-99, 3Dfx Interactive, Inc.  All Rights Reserved.
This kit contains UNPUBLISHED PROPRIETARY SOURCE CODE of 3Dfx Interactive, Inc.
The contents of this kit is protected under the 3DFX GLIDE Source Code 
General Public License. For details see the file glide_license.txt.


Restricted Rights Legend
========================
Use, duplication or disclosure by the Government is subject to restrictions
as set forth in subdivision (c)(1)(ii) of the Rights in Technical Data
and Computer Software clause at DFARS 252.227-7013, and/or in similar or
successor clauses in the FAR, DOD or NASA FAR Supplement. Unpublished -
rights reserved under the Copyright Laws of the United States.

 
Contents:
=========
Glide3 (R) source code.


Installation
============
Simply uncompress the source tree with the directory structure intact 
to any directory on your system. If the directory structure is changed, 
3Dfx considers it to be un-supported as you will not be able to build 
the source with the make-files provided by 3Dfx.  


Compiling
=========
Run "make -f makefile.unix"



