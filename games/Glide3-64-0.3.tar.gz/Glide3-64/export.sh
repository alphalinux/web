#!/bin/sh

LD_LIBRARY_PATH=`pwd`/cvg/glide3/src:$LD_LIBRARY_PATH; export LD_LIBRARY_PATH
