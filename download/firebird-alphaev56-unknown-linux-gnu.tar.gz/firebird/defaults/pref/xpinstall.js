pref("xpinstall.enabled",       true);
pref("xpinstall.manual_confirm",  true);

pref("xpinstall.notifications.enabled",  true);
pref("xpinstall.notifications.interval", 1);
pref("xpinstall.notifications.lastDate", 0);
